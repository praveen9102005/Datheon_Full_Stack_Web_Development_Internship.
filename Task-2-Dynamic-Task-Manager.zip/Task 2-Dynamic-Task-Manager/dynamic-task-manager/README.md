# Dynamic Task Manager & Productivity Tracker

React + Vite frontend, Express backend, and local JSON-file storage. PostgreSQL is not required.

## Requirements
- Node.js 18+

## Run locally
From the project root:

```bash
npm install
npm run install:all
npm run dev
```

Open:
- Frontend: http://localhost:5173
- Backend: http://localhost:5000
- Health check: http://localhost:5000/api/health

## Local data storage
Tasks are saved automatically in `backend/data/tasks.json`. The backend creates this file on first startup. Data remains on this computer when you stop and restart the application.

To back up your tasks, copy `backend/data/tasks.json`. To reset all tasks, stop the backend and replace its contents with:
```json
{
  "tasks": [],
  "nextId": 1
}
```

## PostgreSQL removal
The `pg` package, PostgreSQL connection string, database setup, and SQL schema are no longer needed. You do not need to start PostgreSQL or open pgAdmin.

The existing task CRUD APIs and dashboard endpoints are retained.
