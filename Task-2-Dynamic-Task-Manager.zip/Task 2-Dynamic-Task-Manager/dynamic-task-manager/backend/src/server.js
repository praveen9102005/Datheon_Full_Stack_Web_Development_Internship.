import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import { initializeDatabase } from './db.js';
import tasksRouter from './routes/tasks.js';
import dashboardRouter from './routes/dashboard.js';

dotenv.config();
const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));
app.get('/api/health', (_req, res) => res.json({ status: 'ok', storage: 'local-json-file' }));
app.use('/api/tasks', tasksRouter);
app.use('/api/dashboard', dashboardRouter);
app.use((req, res) => res.status(404).json({ error: `Route not found: ${req.method} ${req.path}` }));
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'An unexpected server error occurred.' });
});

const port = Number(process.env.PORT || 5000);
initializeDatabase()
  .then(() => app.listen(port, () => console.log(`Task Manager API running on http://localhost:${port}`)))
  .catch(err => { console.error('Local storage initialization failed:', err.message); process.exit(1); });
