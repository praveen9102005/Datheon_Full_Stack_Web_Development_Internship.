import { Router } from 'express';
import { readStore, writeStore } from '../db.js';

const router = Router();
const priorities = ['Low', 'Medium', 'High'];
const statuses = ['Active', 'Completed'];

function validate(body, partial = false) {
  if ((!partial || body.title !== undefined) &&
      (typeof body.title !== 'string' || !body.title.trim() || body.title.trim().length > 180)) {
    return 'Title is required and must be 180 characters or fewer.';
  }
  if (body.description !== undefined && typeof body.description !== 'string') return 'Description must be text.';
  if (body.category !== undefined && (typeof body.category !== 'string' || !body.category.trim() || body.category.length > 80)) return 'Category must be 1–80 characters.';
  if (body.priority !== undefined && !priorities.includes(body.priority)) return 'Priority must be Low, Medium, or High.';
  if (body.status !== undefined && !statuses.includes(body.status)) return 'Status must be Active or Completed.';
  if (body.due_date && Number.isNaN(Date.parse(body.due_date))) return 'Due date is invalid.';
  return null;
}
const byId = (store, id) => store.tasks.find(t => String(t.id) === String(id));

router.get('/', async (req, res, next) => {
  try {
    const store = await readStore();
    const { status, category, priority, search, due } = req.query;
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const end = new Date(start); end.setDate(end.getDate() + 1);
    let tasks = store.tasks.filter(t => {
      if (status && status !== 'All' && t.status !== status) return false;
      if (category && category !== 'All' && t.category !== category) return false;
      if (priority && priority !== 'All' && t.priority !== priority) return false;
      if (search && !`${t.title} ${t.description}`.toLowerCase().includes(search.toLowerCase())) return false;
      if (due === 'overdue' && !(t.status === 'Active' && t.due_date && new Date(t.due_date) < now)) return false;
      if (due === 'today' && !(t.due_date && new Date(t.due_date) >= start && new Date(t.due_date) < end)) return false;
      return true;
    }).sort((a,b) => a.position - b.position || new Date(b.created_at) - new Date(a.created_at));
    res.json({ data: tasks });
  } catch (err) { next(err); }
});

router.get('/:id', async (req, res, next) => {
  try {
    const store = await readStore(), task = byId(store, req.params.id);
    if (!task) return res.status(404).json({ error: 'Task not found.' });
    res.json({ data: task });
  } catch (err) { next(err); }
});

router.post('/', async (req, res, next) => {
  try {
    const error = validate(req.body);
    if (error) return res.status(400).json({ error });
    const store = await readStore();
    const now = new Date().toISOString();
    const task = {
      id: store.nextId++, title: req.body.title.trim(),
      description: (req.body.description || '').trim(),
      category: (req.body.category || 'Personal').trim(),
      priority: req.body.priority || 'Medium', status: 'Active',
      due_date: req.body.due_date || null, completed_at: null,
      position: store.tasks.length, created_at: now, updated_at: now
    };
    store.tasks.push(task); await writeStore(store);
    res.status(201).json({ data: task, message: 'Task created.' });
  } catch (err) { next(err); }
});

router.put('/:id', async (req, res, next) => {
  try {
    const error = validate(req.body, true);
    if (error) return res.status(400).json({ error });
    const store = await readStore(), task = byId(store, req.params.id);
    if (!task) return res.status(404).json({ error: 'Task not found.' });
    const oldStatus = task.status;
    for (const key of ['title','description','category','priority','due_date','status']) {
      if (req.body[key] !== undefined) task[key] = key === 'due_date' ? (req.body[key] || null) :
        (typeof req.body[key] === 'string' && ['title','description','category'].includes(key) ? req.body[key].trim() : req.body[key]);
    }
    if (task.status === 'Completed' && oldStatus !== 'Completed') task.completed_at = new Date().toISOString();
    if (task.status !== 'Completed') task.completed_at = null;
    task.updated_at = new Date().toISOString();
    await writeStore(store); res.json({ data: task, message: 'Task updated.' });
  } catch (err) { next(err); }
});

router.patch('/:id/status', async (req, res, next) => {
  try {
    if (!statuses.includes(req.body.status)) return res.status(400).json({ error: 'Status must be Active or Completed.' });
    const store = await readStore(), task = byId(store, req.params.id);
    if (!task) return res.status(404).json({ error: 'Task not found.' });
    task.status = req.body.status;
    task.completed_at = task.status === 'Completed' ? new Date().toISOString() : null;
    task.updated_at = new Date().toISOString();
    await writeStore(store); res.json({ data: task, message: 'Task status updated.' });
  } catch (err) { next(err); }
});

router.patch('/:id/position', async (req, res, next) => {
  try {
    const { position } = req.body;
    if (!Number.isInteger(position) || position < 0) return res.status(400).json({ error: 'Position must be a non-negative integer.' });
    const store = await readStore(), task = byId(store, req.params.id);
    if (!task) return res.status(404).json({ error: 'Task not found.' });
    task.position = position; task.updated_at = new Date().toISOString();
    await writeStore(store); res.json({ data: task });
  } catch (err) { next(err); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    const store = await readStore(), before = store.tasks.length;
    store.tasks = store.tasks.filter(t => String(t.id) !== String(req.params.id));
    if (store.tasks.length === before) return res.status(404).json({ error: 'Task not found.' });
    await writeStore(store); res.json({ message: 'Task deleted.' });
  } catch (err) { next(err); }
});
export default router;
