import { Router } from 'express';
import { readStore } from '../db.js';
const router = Router();

router.get('/stats', async (_req, res, next) => {
  try {
    const { tasks } = await readStore();
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const end = new Date(start); end.setDate(end.getDate() + 1);
    const total = tasks.length;
    const completed = tasks.filter(t => t.status === 'Completed').length;
    const active = tasks.filter(t => t.status === 'Active').length;
    const overdue = tasks.filter(t => t.status === 'Active' && t.due_date && new Date(t.due_date) < now).length;
    const today = tasks.filter(t => t.due_date && new Date(t.due_date) >= start && new Date(t.due_date) < end).length;
    const counts = {};
    tasks.forEach(t => counts[t.category] = (counts[t.category] || 0) + 1);
    const categories = Object.entries(counts).map(([category,count]) => ({category,count})).sort((a,b) => b.count-a.count);
    const trends = Array.from({length:7}, (_,i) => {
      const day = new Date(start); day.setDate(day.getDate() - 6 + i);
      return { day: day.toLocaleDateString('en-US',{weekday:'short'}), date: day.toISOString().slice(0,10),
        completed: tasks.filter(t => t.completed_at && new Date(t.completed_at).toDateString() === day.toDateString()).length };
    });
    res.json({ data: { total, active, completed, overdue, today,
      completionRate: total ? Math.round(completed / total * 100) : 0, categories, trends } });
  } catch (err) { next(err); }
});
export default router;
