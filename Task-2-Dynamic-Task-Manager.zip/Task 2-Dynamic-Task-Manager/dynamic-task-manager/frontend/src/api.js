const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options, headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || 'Request failed. Please try again.');
  return payload;
}
export const api = {
  tasks: (params = {}) => request(`/tasks?${new URLSearchParams(params)}`),
  create: data => request('/tasks', { method: 'POST', body: JSON.stringify(data) }),
  update: (id, data) => request(`/tasks/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  status: (id, status) => request(`/tasks/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
  position: (id, position) => request(`/tasks/${id}/position`, { method: 'PATCH', body: JSON.stringify({ position }) }),
  remove: id => request(`/tasks/${id}`, { method: 'DELETE' }),
  stats: () => request('/dashboard/stats')
};