import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Activity, AlertCircle, ArrowDownUp, BarChart3, CalendarDays, Check, CheckCircle2,
  ChevronDown, Circle, ClipboardList, Clock3, Command, GripVertical, LayoutDashboard,
  ListTodo, Moon, MoreHorizontal, Plus, Search, Settings2, Sun, Target, Trash2,
  TrendingUp, X, Pencil, Filter, Sparkles
} from 'lucide-react';
import { api } from './api';

const filters = ['All tasks', 'Active', 'Completed', 'Overdue', 'Today'];
const blank = { title: '', description: '', category: 'Work', priority: 'Medium', due_date: '' };
const categories = ['Work', 'Personal', 'Study', 'Health', 'Other'];
const dateLabel = value => value ? new Date(value).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : 'No due date';
const isOverdue = task => task.status === 'Active' && task.due_date && new Date(task.due_date) < new Date();

function App() {
  const [tasks, setTasks] = useState([]);
  const [stats, setStats] = useState(null);
  const [filter, setFilter] = useState('All tasks');
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [priority, setPriority] = useState('All');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(blank);
  const [toast, setToast] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [dark, setDark] = useState(false);
  const [dragged, setDragged] = useState(null);

  const notify = message => { setToast(message); window.clearTimeout(notify.timer); notify.timer = window.setTimeout(() => setToast(''), 2800); };
  const load = useCallback(async () => {
    try {
      const [taskResult, statResult] = await Promise.all([api.tasks(), api.stats()]);
      setTasks(taskResult.data); setStats(statResult.data);
    } catch (error) { notify(error.message); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const visible = useMemo(() => tasks.filter(t => {
    const term = search.toLowerCase();
    const matchesText = !term || t.title.toLowerCase().includes(term) || (t.description || '').toLowerCase().includes(term);
    const matchesFilter = filter === 'All tasks' ||
      (filter === 'Active' && t.status === 'Active') ||
      (filter === 'Completed' && t.status === 'Completed') ||
      (filter === 'Overdue' && isOverdue(t)) ||
      (filter === 'Today' && t.due_date && new Date(t.due_date).toDateString() === new Date().toDateString());
    return matchesText && matchesFilter && (category === 'All' || t.category === category) && (priority === 'All' || t.priority === priority);
  }), [tasks, search, filter, category, priority]);

  const openCreate = () => { setEditing(null); setForm(blank); setModal(true); };
  const openEdit = task => {
    setEditing(task); setForm({ title: task.title, description: task.description || '', category: task.category, priority: task.priority,
      due_date: task.due_date ? new Date(task.due_date).toISOString().slice(0, 16) : '' }); setModal(true);
  };
  const saveTask = async e => {
    e.preventDefault(); if (!form.title.trim()) return;
    setBusy(true);
    try {
      const payload = { ...form, due_date: form.due_date ? new Date(form.due_date).toISOString() : null };
      if (editing) await api.update(editing.id, payload); else await api.create(payload);
      setModal(false); notify(editing ? 'Task updated successfully' : 'Task added to your list'); await load();
    } catch (error) { notify(error.message); }
    finally { setBusy(false); }
  };
  const toggle = async task => {
    try { await api.status(task.id, task.status === 'Completed' ? 'Active' : 'Completed'); await load(); }
    catch (error) { notify(error.message); }
  };
  const remove = async task => {
    if (!window.confirm(`Delete “${task.title}”? This cannot be undone.`)) return;
    try { await api.remove(task.id); notify('Task deleted'); await load(); }
    catch (error) { notify(error.message); }
  };
  const reorder = async target => {
    if (!dragged || dragged.id === target.id) return;
    const next = [...visible]; const from = next.findIndex(t => t.id === dragged.id); const to = next.findIndex(t => t.id === target.id);
    next.splice(to, 0, next.splice(from, 1)[0]);
    try {
      await Promise.all(next.map((task, index) => api.position(task.id, index)));
      await load();
    } catch (error) { notify(error.message); }
    setDragged(null);
  };

  const total = stats?.total ?? tasks.length;
  const done = stats?.completed ?? tasks.filter(t => t.status === 'Completed').length;
  const active = stats?.active ?? total - done;
  const rate = stats?.completionRate ?? (total ? Math.round(done / total * 100) : 0);

  return <div className={dark ? 'app dark' : 'app'}>
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Command size={19}/></div><span>taskflow<span className="brand-dot">.</span></span></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>
        <button className="nav-item active"><LayoutDashboard size={18}/> Overview</button>
        <button className="nav-item" onClick={() => setFilter('All tasks')}><ListTodo size={18}/> All tasks <span className="nav-count">{total}</span></button>
        <button className="nav-item" onClick={() => setFilter('Today')}><CalendarDays size={18}/> Today</button>
        <button className="nav-item" onClick={() => setFilter('Completed')}><CheckCircle2 size={18}/> Completed</button>
      </nav>
      <div className="sidebar-divider"/>
      <div className="workspace-label">YOUR CATEGORIES</div>
      {categories.map((c, i) => <button key={c} className="category-link" onClick={() => {setCategory(category === c ? 'All' : c); setFilter('All tasks');}}><span className={`category-dot dot-${i}`}/>{c}<span className="category-total">{tasks.filter(t => t.category === c).length}</span></button>)}
      <div className="sidebar-bottom">
        <div className="focus-card"><div className="focus-icon"><Target size={17}/></div><strong>Stay in your flow</strong><p>Small steps lead to big progress. Keep going!</p><div className="focus-progress"><span style={{width: `${rate}%`}}/></div><small>{rate}% tasks completed</small></div>
        <div className="profile"><div className="avatar">P</div><div><strong>My workspace</strong><small>Personal account</small></div><MoreHorizontal size={18}/></div>
      </div>
    </aside>

    <main className="main">
      <header className="topbar">
        <div className="breadcrumb">Workspace <span>/</span> <strong>Overview</strong></div>
        <div className="top-actions"><div className="date-chip"><CalendarDays size={15}/>{new Date().toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric'})}</div><button className="icon-btn" aria-label="Toggle theme" onClick={() => setDark(!dark)}>{dark ? <Sun size={18}/> : <Moon size={18}/>}</button><div className="avatar small">P</div></div>
      </header>

      <section className="welcome">
        <div><div className="eyebrow"><Sparkles size={14}/> YOUR PRODUCTIVITY SPACE</div><h1>Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening'} 👋</h1><p>Make today count. Here's what's happening with your tasks.</p></div>
        <button className="primary-btn" onClick={openCreate}><Plus size={18}/> New task</button>
      </section>

      <section className="stats-grid">
        <Stat icon={<ClipboardList size={19}/>} label="Total tasks" value={total} note="Across your workspace" tone="blue"/>
        <Stat icon={<Activity size={19}/>} label="In progress" value={active} note="Tasks to keep moving" tone="violet"/>
        <Stat icon={<CheckCircle2 size={19}/>} label="Completed" value={done} note={`${rate}% completion rate`} tone="green"/>
        <Stat icon={<AlertCircle size={19}/>} label="Overdue" value={stats?.overdue ?? tasks.filter(isOverdue).length} note="Need your attention" tone="orange"/>
      </section>

      <section className="content-grid">
        <div className="task-panel panel">
          <div className="panel-heading"><div><h2>My tasks</h2><p>Organize your day, one task at a time.</p></div><button className="secondary-btn" onClick={openCreate}><Plus size={16}/> Add task</button></div>
          <div className="toolbar">
            <div className="search-box"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search tasks..."/><kbd>⌘ K</kbd></div>
            <div className="filter-select"><Filter size={15}/><select value={category} onChange={e => setCategory(e.target.value)}><option value="All">All categories</option>{[...new Set([...categories, ...tasks.map(t=>t.category)])].map(c=><option key={c}>{c}</option>)}</select><ChevronDown size={14}/></div>
            <div className="filter-select priority-select"><select value={priority} onChange={e => setPriority(e.target.value)}><option value="All">All priorities</option>{['High','Medium','Low'].map(p=><option key={p}>{p}</option>)}</select><ChevronDown size={14}/></div>
          </div>
          <div className="tabs">{filters.map(f=><button key={f} className={filter===f?'tab active':'tab'} onClick={()=>setFilter(f)}>{f}{f==='All tasks' && <span>{total}</span>}</button>)}</div>
          <div className="task-list">
            {loading ? <div className="empty-state"><div className="spinner"/><p>Loading your tasks...</p></div> :
              visible.length ? visible.map(task=><article key={task.id} className={`task-row ${task.status==='Completed'?'is-complete':''}`} draggable onDragStart={()=>setDragged(task)} onDragOver={e=>e.preventDefault()} onDrop={()=>reorder(task)}>
                <div className="drag-handle"><GripVertical size={17}/></div>
                <button className={`check-btn ${task.status==='Completed'?'checked':''}`} onClick={()=>toggle(task)} aria-label="Toggle completion">{task.status==='Completed'?<Check size={14}/>:<Circle size={19}/>}</button>
                <div className="task-info"><div className="task-title">{task.title}</div>{task.description && <p>{task.description}</p>}<div className="task-meta"><span className={`tag tag-${task.category.toLowerCase()}`}>{task.category}</span><span className={`priority priority-${task.priority.toLowerCase()}`}><i/>{task.priority}</span><span className={`due ${isOverdue(task)?'late':''}`}><CalendarDays size={13}/>{dateLabel(task.due_date)}{isOverdue(task)?' · Overdue':''}</span></div></div>
                <div className="row-actions"><button className="icon-btn" onClick={()=>openEdit(task)} aria-label="Edit task"><Pencil size={15}/></button><button className="icon-btn danger-hover" onClick={()=>remove(task)} aria-label="Delete task"><Trash2 size={15}/></button></div>
              </article>) : <div className="empty-state"><div className="empty-icon"><ListTodo size={25}/></div><strong>{search || filter!=='All tasks' || category!=='All' || priority!=='All' ? 'No matching tasks' : 'Your task list is clear'}</strong><p>{search || filter!=='All tasks' ? 'Try changing your search or filters.' : 'Add your first task and start building momentum.'}</p>{!search && filter==='All tasks' && <button className="primary-btn" onClick={openCreate}><Plus size={16}/> Create a task</button>}</div>}
          </div>
          <div className="list-footer"><span>Showing <strong>{visible.length}</strong> of <strong>{total}</strong> tasks</span><span><GripVertical size={13}/> Drag tasks to reorder</span></div>
        </div>

        <div className="right-column">
          <div className="panel progress-panel"><div className="panel-heading compact"><div><h2>Completion rate</h2><p>Your progress so far</p></div><div className="mini-icon"><TrendingUp size={17}/></div></div><div className="progress-content"><div className="donut" style={{'--progress':`${rate*3.6}deg`}}><div><strong>{rate}%</strong><small>completed</small></div></div><div className="progress-legend"><div><i className="legend-green"/><span>Completed</span><strong>{done}</strong></div><div><i className="legend-gray"/><span>Remaining</span><strong>{active}</strong></div></div></div></div>
          <div className="panel category-panel"><div className="panel-heading compact"><div><h2>By category</h2><p>Where your time goes</p></div><BarChart3 size={18} className="muted-icon"/></div>
            <div className="category-bars">{(stats?.categories?.length ? stats.categories : categories.map(c=>({category:c,count:0}))).slice(0,5).map((c,i)=><div className="bar-item" key={c.category}><div className="bar-label"><span>{c.category}</span><strong>{c.count}</strong></div><div className="bar-track"><span style={{width:`${total?Math.max(3,c.count/total*100):0}%`}} className={`bar-fill bar-${i}`}/></div></div>)}</div>
          </div>
          <div className="tip-card"><div className="tip-spark"><Sparkles size={17}/></div><div><strong>A little productivity tip</strong><p>Break larger tasks into smaller steps. A clear next action makes it easier to get started.</p></div></div>
        </div>
      </section>
      <footer className="footer">Made for focused work <span>·</span> Your progress is saved automatically</footer>
    </main>

    {modal && <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setModal(false);}}><form className="task-modal" onSubmit={saveTask}>
      <div className="modal-head"><div><span className="eyebrow">TASK DETAILS</span><h2>{editing?'Edit task':'Create a new task'}</h2></div><button type="button" className="icon-btn" onClick={()=>setModal(false)}><X size={19}/></button></div>
      <label>Task title <span>*</span><input autoFocus maxLength="180" required placeholder="What needs to get done?" value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/></label>
      <label>Description <textarea rows="3" placeholder="Add a few details (optional)" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label>
      <div className="form-row"><label>Category<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{categories.map(c=><option key={c}>{c}</option>)}</select></label><label>Priority<select value={form.priority} onChange={e=>setForm({...form,priority:e.target.value})}>{['Low','Medium','High'].map(p=><option key={p}>{p}</option>)}</select></label></div>
      <label>Due date and time<input type="datetime-local" value={form.due_date} onChange={e=>setForm({...form,due_date:e.target.value})}/></label>
      <div className="modal-actions"><button type="button" className="secondary-btn" onClick={()=>setModal(false)}>Cancel</button><button className="primary-btn" disabled={busy}>{busy?'Saving...':editing?'Save changes':'Create task'} <ArrowDownUp size={15}/></button></div>
    </form></div>}
    {toast && <div className="toast"><CheckCircle2 size={17}/>{toast}</div>}
  </div>;
}

function Stat({icon,label,value,note,tone}) { return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div className="stat-copy"><span>{label}</span><strong>{value}</strong><small>{note}</small></div><div className={`stat-accent ${tone}`}/></div>; }
export default App;
