# MAXCART — Premium E-Commerce Store

A responsive storefront built with HTML5, CSS3 and Vanilla JavaScript.

## Run locally
1. Extract the ZIP.
2. Open the `MAXCART-ecommerce-store` folder in VS Code.
3. Install the **Live Server** extension if needed.
4. Right-click `index.html` → **Open with Live Server**.

Alternatively, run `python -m http.server 5500` in this folder and visit `http://localhost:5500`.

## Catalog and product photos
- The app fetches its initial seed catalog from FakeStoreAPI (`https://fakestoreapi.com/products`).
- FakeStoreAPI has a small fixed catalog, so the storefront adds locally generated product records to reach 520 unique entries.
- Generated products now use product-family photo pools: smartphones show phones, laptops show laptops, audio products show headphones/earbuds/speakers, jewelry types have their own ring/necklace/bracelet/earring imagery, and clothing types use matching apparel, shoes and bag photography.
- Each product family rotates through multiple distinct photo URLs rather than reusing only a few generic category photos.
- Product image frames are constrained so portrait photos cannot overflow product cards.

## Features
- 520 products across Electronics, Jewelry and Clothing
- Search by title, brand, category and description
- Category, price, rating and stock filters
- Sorting and load-more pagination
- Quick-view product details
- Slide-out cart with quantity controls
- Subtotal, 5% tax, ₹99 shipping below ₹2,999, and grand total
- LocalStorage cart and wishlist persistence
- Simulated checkout (no real payments or credential storage)
- Responsive desktop, tablet and mobile layout

## Notes
- Product photos and FakeStoreAPI require an internet connection.
- Photo URLs are served from Unsplash and FakeStoreAPI; availability depends on those services.
- This is a frontend demo. Orders are not sent to a server and no real payment is processed.
- Cart and wishlist are stored in the current browser's LocalStorage.
