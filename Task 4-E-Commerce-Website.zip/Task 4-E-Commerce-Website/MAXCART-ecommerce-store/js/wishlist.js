import {getWishlist,saveWishlist} from './storage.js';
export const wishlistIds=()=>getWishlist();
export function toggleWishlist(id){let list=getWishlist();list=list.includes(id)?list.filter(x=>x!==id):[...list,id];saveWishlist(list);return list}
