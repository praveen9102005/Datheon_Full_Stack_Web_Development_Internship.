const API = 'https://fakestoreapi.com/products';

// Product-specific photo pools. Each product family has its own images instead
// of rotating a tiny set of generic category photos across the whole catalog.
const photo = (id) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=700&q=85`;
const productTypes = {
  Electronics: [
    { name: 'Wireless Studio Headphones', subcategory: 'Headphones', photos: ['photo-1505740420928-5e560c06d30f','photo-1546435770-a3e426bf472b','photo-1484704849700-f032a568e944','photo-1583394838336-acd977736f90'] },
    { name: 'Everyday Smart Phone', subcategory: 'Smartphones', photos: ['photo-1511707171634-5f897ff02aa9','photo-1598327105666-5b89351aff97','photo-1512499617640-c74ae3a79d37','photo-1592750475338-74b7b21085ab'] },
    { name: 'UltraBook Air Laptop', subcategory: 'Laptops', photos: ['photo-1496181133206-80ce9b88a853','photo-1517336714731-489689fd1ca8','photo-1498050108023-c5249f4df085','photo-1588872657578-7efd1f1555ed'] },
    { name: 'Active Smart Watch', subcategory: 'Smart Watches', photos: ['photo-1523275335684-37898b6baf30','photo-1546868871-7041f2a55e12','photo-1579586337278-3befd40fd17a','photo-1508685096489-7aacd43bd3b1'] },
    { name: 'Portable Bluetooth Speaker', subcategory: 'Accessories', photos: ['photo-1608043152269-423dbba4e7e1','photo-1589003077984-894e133dabab','photo-1608156639585-b3a032ef9689'] },
    { name: 'Mirrorless Digital Camera', subcategory: 'Cameras', photos: ['photo-1516035069371-29a1b244cc32','photo-1502920917128-1aa500764cbd','photo-1510127034890-3c6e1d7b7f42','photo-1519183071298-a2962be90b8e'] },
    { name: 'Fast Charge Power Bank', subcategory: 'Accessories', photos: ['photo-1609091839311-d5365f9ff1c5','photo-1591290619762-c5887d0c6b1d','photo-1609592806596-b43bada4f9c5'] },
    { name: 'Wireless Earbuds Pro', subcategory: 'Headphones', photos: ['photo-1606220945770-b5b6c2c55bf1','photo-1590658268037-6bf12165a8df','photo-1608156639585-b3a032ef9689'] },
    { name: 'Mechanical Keyboard', subcategory: 'Accessories', photos: ['photo-1587829741301-dc798b83add3','photo-1595225476474-87563907a212','photo-1587829741301-dc798b83add3'] },
    { name: 'Precision Gaming Mouse', subcategory: 'Accessories', photos: ['photo-1527814050087-3793815479db','photo-1615663245857-ac93bb7c39e7','photo-1527864550417-7fd91fc51a46'] },
    { name: '4K Streaming Monitor', subcategory: 'Accessories', photos: ['photo-1527443224154-c4a3942d3acf','photo-1585792180666-f7347c490ee2','photo-1593640408182-31c70c8268f5'] },
    { name: 'Compact Tablet', subcategory: 'Accessories', photos: ['photo-1544244015-0df4b3ffc6b0','photo-1561154464-82e9adf32764','photo-1589739900243-4b52cd9dd8df'] }
  ],
  Jewelry: [
    { name: 'Sculpted Gold Ring', subcategory: 'Rings', photos: ['photo-1605100804763-247f67b3557e','photo-1603561596112-0a132b757442','photo-1617038220319-276d3cfab638','photo-1602173574767-37ac01994b2a'] },
    { name: 'Minimal Pendant Necklace', subcategory: 'Necklaces', photos: ['photo-1599643478518-a784e5dc4c8f','photo-1611652022419-a9419f74343d','photo-1515562141207-7a88fb7ce338','photo-1611085583191-a3b181a88401'] },
    { name: 'Classic Hoop Earrings', subcategory: 'Earrings', photos: ['photo-1535632066927-ab7c9ab60908','photo-1617038220319-276d3cfab638','photo-1630019852942-f89202989a59','photo-1617038260897-41a1f14a8ca0'] },
    { name: 'Silver Charm Bracelet', subcategory: 'Bracelets', photos: ['photo-1611652022419-a9419f74343d','photo-1573408301185-9146fe634ad0','photo-1611591437281-460bfbe1220a','photo-1611652022419-a9419f74343d'] },
    { name: 'Pearl Drop Earrings', subcategory: 'Earrings', photos: ['photo-1617038220319-276d3cfab638','photo-1535632066927-ab7c9ab60908','photo-1635767798638-3665a7b2b6c4'] },
    { name: 'Layered Chain Necklace', subcategory: 'Necklaces', photos: ['photo-1515562141207-7a88fb7ce338','photo-1599643478518-a784e5dc4c8f','photo-1611085583191-a3b181a88401'] },
    { name: 'Gemstone Statement Ring', subcategory: 'Rings', photos: ['photo-1603561596112-0a132b757442','photo-1605100804763-247f67b3557e','photo-1602173574767-37ac01994b2a'] },
    { name: 'Everyday Cuff Bracelet', subcategory: 'Bracelets', photos: ['photo-1573408301185-9146fe634ad0','photo-1611591437281-460bfbe1220a','photo-1611652022419-a9419f74343d'] },
    { name: 'Modern Analog Watch', subcategory: 'Watches', photos: ['photo-1523275335684-37898b6baf30','photo-1524805444758-089113d48a6d','photo-1508685096489-7aacd43bd3b1'] },
    { name: 'Delicate Tennis Bracelet', subcategory: 'Bracelets', photos: ['photo-1611591437281-460bfbe1220a','photo-1573408301185-9146fe634ad0','photo-1611652022419-a9419f74343d'] }
  ],
  Clothing: [
    { name: 'Essential Cotton T-Shirt', subcategory: "Men's Clothing", photos: ['photo-1521572163474-6864f9cf17ab','photo-1583743814966-8936f37f4678','photo-1627225924765-552d49cf47ad','photo-1576566588028-4147f3842f27'] },
    { name: 'Everyday Runner Sneakers', subcategory: 'Shoes', photos: ['photo-1542291026-7eec264c27ff','photo-1543163521-1bf539c55dd2','photo-1600185365483-26d7a4cc7519','photo-1460353581641-37baddab0fa2'] },
    { name: 'Relaxed Fit Denim', subcategory: "Men's Clothing", photos: ['photo-1542272604-787c3835535d','photo-1582418702059-97ebafb35d09','photo-1541099649105-f69ad21f3246'] },
    { name: 'Structured Crossbody Bag', subcategory: 'Accessories', photos: ['photo-1548036328-c9fa89d128fa','photo-1584917865442-de89df76afd3','photo-1590874103328-eac38a683ce7','photo-1553062407-98eeb64c6a62'] },
    { name: 'Classic Overshirt', subcategory: "Men's Clothing", photos: ['photo-1598033129183-c4f50c736f10','photo-1603252109303-2751441dd157','photo-1603252110481-7e8e6d0b4c2a'] },
    { name: 'Linen Blend Shirt', subcategory: "Women's Clothing", photos: ['photo-1596755094514-f87e34085b2c','photo-1603252109303-2751441dd157','photo-1551488831-00ddcb6c6bd3'] },
    { name: 'Tailored Wide-Leg Trousers', subcategory: 'Formal Wear', photos: ['photo-1506629905607-d9c297dcd7a8','photo-1594633312681-425c7b97ccd1','photo-1598554747436-c9293d6a588f'] },
    { name: 'Minimal Leather Jacket', subcategory: 'Formal Wear', photos: ['photo-1551028719-00167b16eac5','photo-1544923246-77307dd654cb','photo-1591047139829-d91aecb6caea'] },
    { name: 'Weekend Hoodie', subcategory: 'Casual Wear', photos: ['photo-1556821840-3a63f95609a7','photo-1578681994506-b8f463449011','photo-1565693413579-8a9a4a8c8a6b'] },
    { name: 'Everyday Canvas Tote', subcategory: 'Accessories', photos: ['photo-1590874103328-eac38a683ce7','photo-1544816155-12df9643f363','photo-1584917865442-de89df76afd3'] },
    { name: 'Ribbed Knit Top', subcategory: "Women's Clothing", photos: ['photo-1576566588028-4147f3842f27','photo-1578587018452-892bacefd3f2','photo-1551163943-3f6a855d1153'] },
    { name: 'Classic Low-Top Shoes', subcategory: 'Shoes', photos: ['photo-1600185365483-26d7a4cc7519','photo-1542291026-7eec264c27ff','photo-1460353581641-37baddab0fa2'] }
  ]
};

const brands = {
  Electronics: ['Auralab','Nexa','Voltix','Orbit','Soundform','PixelWorks'],
  Jewelry: ['Aurelia','Mira & Co.','Lustre','Forma','Solenne','Atelier 8'],
  Clothing: ['Common Thread','Northline','Studio Form','Everyday Co.','Morrow','Mode']
};
const adjectives = ['Essential','Modern','Premium','Signature','Classic','Studio','Urban','Lightweight','Refined','Everyday','Limited','Minimal','Elevated','Travel','Active','Smart'];
const money = n => Math.round(n * 100) / 100;

function generated(id, category, index) {
  const type = productTypes[category][index % productTypes[category].length];
  const variant = Math.floor(index / productTypes[category].length);
  const adjective = adjectives[variant % adjectives.length];
  const brand = brands[category][index % brands[category].length];
  const price = category === 'Electronics' ? 699 + ((index * 379) % 72000) : category === 'Jewelry' ? 399 + ((index * 173) % 16000) : 499 + ((index * 239) % 12000);
  const discount = 8 + (index * 7) % 38;
  const images = type.photos;
  const image = photo(images[variant % images.length]);
  return {
    id, title: `${adjective} ${type.name} ${variant + 1}`, price: money(price),
    originalPrice: money(price / (1 - discount / 100)),
    description: `A thoughtfully designed ${type.name.toLowerCase()} from ${brand}. Made for everyday use, with considered details, dependable quality and a clean, versatile finish.`,
    category, subcategory: type.subcategory, brand, image,
    rating: money(3.7 + ((index * 13) % 13) / 10), reviews: 34 + (index * 47) % 1800,
    stock: 1 + (index * 11) % 45,
    badge: ['BEST SELLER','NEW ARRIVAL','LIMITED OFFER','TRENDING','SALE'][index % 5],
    popularity: 1000 - (index % 500)
  };
}

function inferSubcategory(category, title, index) {
  const value = title.toLowerCase();
  if (category === 'Electronics') {
    if (/phone|iphone|smartphone/.test(value)) return 'Smartphones';
    if (/laptop|notebook/.test(value)) return 'Laptops';
    if (/headphone|earbud|earphone/.test(value)) return 'Headphones';
    if (/watch/.test(value)) return 'Smart Watches';
    if (/camera/.test(value)) return 'Cameras';
    return 'Accessories';
  }
  if (category === 'Jewelry') {
    if (/ring/.test(value)) return 'Rings';
    if (/necklace|chain|pendant/.test(value)) return 'Necklaces';
    if (/bracelet/.test(value)) return 'Bracelets';
    if (/earring/.test(value)) return 'Earrings';
    return 'Watches';
  }
  return /shoe|sneaker|boot/.test(value) ? 'Shoes' : /bag|backpack|tote/.test(value) ? 'Accessories' : /jacket|trouser|formal/.test(value) ? 'Formal Wear' : 'Clothing';
}

export async function loadProducts() {
  let api = [];
  try {
    const res = await fetch(API, { signal: AbortSignal.timeout(9000) });
    if (!res.ok) throw new Error('API unavailable');
    api = await res.json();
  } catch (error) {
    console.warn('FakeStoreAPI unavailable; using the local product catalog.', error);
  }

  const normalized = api.map((p, i) => {
    const cat = /jewel/i.test(p.category) ? 'Jewelry' : /clothing/i.test(p.category) ? 'Clothing' : 'Electronics';
    return {
      id: p.id, title: p.title, price: p.price, originalPrice: money(p.price * 1.18),
      description: p.description, category: cat,
      subcategory: inferSubcategory(cat, p.title, i),
      brand: brands[cat][i % brands[cat].length], image: p.image,
      rating: p.rating?.rate || 4.2, reviews: p.rating?.count || 50,
      stock: 8 + (i * 7) % 30, badge: i % 3 === 0 ? 'BEST SELLER' : 'POPULAR',
      popularity: p.rating?.count || 50
    };
  });

  const result = [...normalized];
  const categories = ['Electronics','Jewelry','Clothing'];
  const counts = { Electronics: 0, Jewelry: 0, Clothing: 0 };
  let id = 1001;
  let turn = 0;
  while (result.length < 520) {
    const category = categories[turn % categories.length];
    result.push(generated(id++, category, counts[category]++));
    turn++;
  }
  return result;
}
