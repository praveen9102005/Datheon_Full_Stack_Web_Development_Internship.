const safeRead=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}};
export const getCart=()=>safeRead('maxcart_cart',[]);
export const saveCart=items=>localStorage.setItem('maxcart_cart',JSON.stringify(items));
export const getWishlist=()=>safeRead('maxcart_wishlist',[]);
export const saveWishlist=items=>localStorage.setItem('maxcart_wishlist',JSON.stringify(items));
export const getRecent=()=>safeRead('maxcart_recent',[]);
export const saveRecent=items=>localStorage.setItem('maxcart_recent',JSON.stringify(items));
