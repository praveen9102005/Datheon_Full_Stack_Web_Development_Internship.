import {getCart,saveCart} from './storage.js';
export const TAX_RATE=.05,FREE_SHIPPING=2999,SHIPPING_FEE=99;
export const money=n=>new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(n||0);
export function cartItems(){return getCart()}
export function addToCart(product,qty=1){const cart=getCart(),found=cart.find(x=>x.id===product.id);if(found)found.qty=Math.min(99,found.qty+qty);else cart.push({id:product.id,title:product.title,price:product.price,image:product.image,qty});saveCart(cart);return cart}
export function changeQty(id,delta){let cart=getCart().map(x=>x.id===id?{...x,qty:Math.max(1,Math.min(99,x.qty+delta))}:x);saveCart(cart);return cart}
export function removeFromCart(id){const cart=getCart().filter(x=>x.id!==id);saveCart(cart);return cart}
export function clearCart(){saveCart([])}
export function totals(cart=getCart()){const subtotal=cart.reduce((s,x)=>s+x.price*x.qty,0),tax=subtotal*TAX_RATE,shipping=subtotal===0||subtotal>=FREE_SHIPPING?0:SHIPPING_FEE;return{subtotal,tax,shipping,total:subtotal+tax+shipping,count:cart.reduce((s,x)=>s+x.qty,0)}}
