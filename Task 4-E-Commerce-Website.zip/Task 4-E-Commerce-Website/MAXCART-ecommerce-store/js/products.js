import {getRecent,saveRecent} from './storage.js';
export function rememberProduct(id){let recent=getRecent().filter(x=>x!==id);recent.unshift(id);saveRecent(recent.slice(0,8))}
export function filteredProducts(products,state){
 let list=[...products];const q=state.query.trim().toLowerCase();
 if(q)list=list.filter(p=>[p.title,p.brand,p.category,p.subcategory,p.description].join(' ').toLowerCase().includes(q));
 if(state.category!=='all')list=list.filter(p=>p.category===state.category);
 if(state.min!==null)list=list.filter(p=>p.price>=state.min);
 if(state.max!==null)list=list.filter(p=>p.price<=state.max);
 if(state.rating)list=list.filter(p=>p.rating>=state.rating);
 if(state.stock)list=list.filter(p=>p.stock>0);
 switch(state.sort){case'price-asc':list.sort((a,b)=>a.price-b.price);break;case'price-desc':list.sort((a,b)=>b.price-a.price);break;case'rating':list.sort((a,b)=>b.rating-a.rating);break;case'popular':list.sort((a,b)=>b.popularity-a.popularity);break;case'name':list.sort((a,b)=>a.title.localeCompare(b.title));break;case'newest':list.sort((a,b)=>b.id-a.id);break}
 return list;
}
